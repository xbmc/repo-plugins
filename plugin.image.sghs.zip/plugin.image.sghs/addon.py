import sys
import urllib2
import xbmcgui
import xbmcplugin
from datetime import datetime

addon_handle = int(sys.argv[1])

xbmcplugin.setContent(addon_handle,'picture')
dialog = xbmcgui.Dialog()
currentYear=datetime.now().strftime('%Y')
yearCount=int(currentYear)-2010;
yearList=[]
for index in range (2010,int(currentYear)+1):
	yearList.append(str(index))
ret=dialog.select('Annee',yearList)
year=str(2010+ret)
request = urllib2.Request('http://www.sghs.fr/data/slides/list.txt', headers={'User-Agent' : "Magic Browser"}) 
textFile = urllib2.urlopen(request)
for line in textFile:
	thisYear=line.find(year)
	if thisYear>=0 :
		title=line[12:-1]
		url='http://www.sghs.fr/'+line[:-1]
		li = xbmcgui.ListItem(title)
		xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

xbmcplugin.endOfDirectory(addon_handle)
