import xbmcaddon

MainBase = 'goo.gl/exiAZW'
addon = xbmcaddon.Addon('plugin.video.RTK')